export default {
  navigationBarTitleText: '停车收费系统'
}
