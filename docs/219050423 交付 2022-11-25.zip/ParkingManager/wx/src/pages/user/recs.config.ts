export default {
    navigationBarTitleText: '缴费管理'
}
