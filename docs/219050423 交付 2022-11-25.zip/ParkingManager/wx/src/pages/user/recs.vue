<template>
    <view class="recs-page">
        <CarList />
    </view>
</template>

<script setup lang="ts">
import CarList from '@/components/CarList.vue'
</script>

<style lang="scss">
.recs-page {
    padding: 20px;
}
</style>
