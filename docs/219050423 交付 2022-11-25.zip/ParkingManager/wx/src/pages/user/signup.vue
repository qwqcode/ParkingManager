<template>
    <view class="signup-page">

    </view>
</template>

<script setup lang="ts">

</script>

<style lang="scss">
.signup-page {

}
</style>
