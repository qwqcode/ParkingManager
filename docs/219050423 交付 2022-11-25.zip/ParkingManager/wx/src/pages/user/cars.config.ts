export default {
    navigationBarTitleText: '车牌管理'
}
