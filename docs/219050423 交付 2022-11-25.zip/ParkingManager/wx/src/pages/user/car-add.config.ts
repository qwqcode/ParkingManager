export default {
    navigationBarTitleText: '添加车牌'
}
