export default {
    navigationBarTitleText: '注册'
}
