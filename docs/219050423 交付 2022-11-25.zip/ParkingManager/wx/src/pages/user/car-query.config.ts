export default {
  navigationBarTitleText: '停车缴费'
}
