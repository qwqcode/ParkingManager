export default {
    navigationBarTitleText: '收费规则'
}
