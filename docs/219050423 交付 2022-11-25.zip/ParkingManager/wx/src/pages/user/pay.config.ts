export default {
    navigationBarTitleText: '缴费'
}
