export default {
    navigationBarTitleText: '缴费成功'
}
