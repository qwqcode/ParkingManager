package com.qwqcode.parkingmanager.model.req;

public class UserCarQueryParams {
    private String car_plate;
    private int car_id;

    public String getCar_plate() {
        return car_plate;
    }

    public void setCar_plate(String car_plate) {
        this.car_plate = car_plate;
    }

    public int getCar_id() {
        return car_id;
    }

    public void setCar_id(int car_id) {
        this.car_id = car_id;
    }
}
