package com.qwqcode.parkingmanager.model.req;

public class UserUnbindCarParams {
    private int car_id;

    public int getCar_id() {
        return car_id;
    }

    public void setCar_id(int car_id) {
        this.car_id = car_id;
    }
}
