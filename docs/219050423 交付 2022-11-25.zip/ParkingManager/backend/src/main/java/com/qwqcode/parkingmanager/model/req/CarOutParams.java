package com.qwqcode.parkingmanager.model.req;

public class CarOutParams {
    private String car_plate;

    public String getCar_plate() {
        return car_plate;
    }

    public void setCar_plate(String car_plate) {
        this.car_plate = car_plate;
    }
}
