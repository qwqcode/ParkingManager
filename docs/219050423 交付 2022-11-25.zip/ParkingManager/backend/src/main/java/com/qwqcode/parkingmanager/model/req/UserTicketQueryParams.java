package com.qwqcode.parkingmanager.model.req;

public class UserTicketQueryParams {
    private String ticket_key;

    public String getTicket_key() {
        return ticket_key;
    }

    public void setTicket_key(String ticket_key) {
        this.ticket_key = ticket_key;
    }
}
