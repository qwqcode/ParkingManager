<script setup lang="ts">
import DefaultLayout from './layout/DefaultLayout.vue'
</script>

<template>
  <DefaultLayout>
    <router-view />
  </DefaultLayout>
</template>

<style scoped>

</style>
